#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>
#include <SDL.h>
#include <SDL2/SDL_image.h>

//THIS PROGRAM IS MADE BY JOHN WINNSTON 1706064675
//						  KAIZEN LOLO   1706064681

/*With help from: https://stackoverflow.com/questions/18421619/c-language-record-data-add-delete-in-text-file-using-file-io-structure-fun
				  https://stackoverflow.com/questions/19473629/file-and-fp-translation
				  https://www.programiz.com/c-programming/c-file-input-output
				  https://www.geeksforgeeks.org/swap-nodes-in-a-linked-list-without-swapping-data/										*/

struct contact
{
  char fname[20];
  char lname[20];
  char phone[20];
  int image;
  struct contact *next;
};

struct contact *head = NULL;

int menuMain();
int menuDelete();
int menuSearch();
int menuSort();

void displayContact(int max);
int addContact(int max);

void deleteFirst();
void deleteLast();
void deleteNum();

void searchFirst();
void searchLast();
void searchNum();

void sortFirst();
void sortLast();
void sortNum();

void saveFile();
int loadFile();
int isEmpty();
void openPicture(char* filename, int max);

int main()
{   int max;
	max=loadFile();
	int choice,choice1,choice2,choice3;
	choice=menuMain();
    while(choice!=7){
		switch(choice)
	    {
	    case 1:
	    	if(!isEmpty()){
	    		displayContact(max);
	    	}
	    	else{
	    		printf("List is empty.\n");
	    		system("pause");
			}
			break;
	    case 2:
	    	max=addContact(max);
	        break;
	    case 3:
	    	choice1=0;
			if(!isEmpty()){
	    		while(choice1<1||choice1>4){
	    			choice1=menuDelete();
	    			if(choice1<1||choice1>4){
				        	printf("\tInvalid Choice\n");
				            system("pause");
					}
	    		}
			 	switch(choice1)
			    {
			        case 1:
			    		deleteFirst();
						break;
			        case 2:
			        	deleteLast();
			        	break;
			        case 3:
			            deleteNum();
			            break;
			        case 4:
			        	break;
			    }
	    	}
	    	else{
	    		printf("List is empty.\n");
	    		system("pause");
			}
			break;
	    case 4:
	    	choice2=0;
	    	if(!isEmpty()){
	    		while(choice2<1||choice2>4){
	    			choice2=menuSearch();
	    			if(choice2<1||choice2>4){
				        	printf("\tInvalid Choice\n");
				            system("pause");
					}
	    		}
				switch(choice2)
				{
			        case 1:
			    		searchFirst();
						break;
			        case 2:
			        	searchLast();
			        	break;
			        case 3:
			            searchNum();
			            break;
			        case 4:
			        	break;
				}
	    	}
	    	else{
	    		printf("List is empty.\n");
	    		system("pause");
			}
			break;
	    case 5:
	    	choice3=0;
			if(!isEmpty()){
	    		while(choice3<1||choice3>4){
	    			choice3=menuSort();
	    			if(choice3<1||choice3>4){
				        	printf("\tInvalid Choice\n");
				            system("pause");
					}
	    		}
			 	switch(choice3)
			    {
			        case 1:
			    		sortFirst();
						break;
			        case 2:
			        	sortLast();
			        	break;
			        case 3:
			            sortNum();
			            break;
			        case 4:
			        	break;
			    }
	    	}
	    	else{
	    		printf("List is empty.\n");
	    		system("pause");
			}
	    	break;
	    case 6:
	    	saveFile();
	    	break;
	    default:
	    	printf("\tInvalid Choice\n");
	    	system("pause");
	    	break;
		}
		choice=menuMain();
	}
		return 0;
	}


int menuMain(){
	system("cls");
    printf("\tPHONE BOOK\n\n");
    printf("[1] Display Contact\n");
    printf("[2] Add Contact\n");
    printf("[3] Delete Contact\n");
    printf("[4] Search Contact\n");
    printf("[5] Sort Contact\n");
    printf("[6] Save to File\n");
    printf("[7] Exit\n");
    printf("\nEnter Your Choice: ");

    int choice;
    scanf("%d",&choice);
    return choice;
}

int menuDelete()
{
  	system("cls");
	printf("\tDELETE CONTACT  \n\n");
    printf("Please Select one of the following Options :\n\n");
    printf("1. Delete using first name\n");
    printf("2. Delete using last name\n");
    printf("3. Delete using Phone number\n");
    printf("4. Return to Main Menu\n\n");
    printf("\nEnter Your Choice: ");
    int choice1;
	scanf("%d",&choice1);
	return choice1;
}

int menuSearch()
	{
		system("cls");
		printf("\tSEARCH CONTACT  \n\n");
		printf("Please Select one of the following Options :\n\n");
		printf("1. Search using first name\n");
    	printf("2. Search using last name\n");
    	printf("3. Search using Phone number\n");
    	printf("4. Return to Main Menu\n\n");
	    printf("\nEnter Your Choice: ");
	    int choice2;
		scanf("%d",&choice2);
		return choice2;
	}

	int menuSort()
	{
		system("cls");
		printf("\tSORT CONTACT  \n\n");
		printf("Please Select one of the following Options :\n\n");
		printf("1. Sort using first name\n");
    	printf("2. Sort using last name\n");
    	printf("3. Sort using Phone number\n");
    	printf("4. Return to Main Menu\n\n");
	    printf("\nEnter Your Choice: ");
	    int choice3;
		scanf("%d",&choice3);
		return choice3;
	}

void displayContact(int max){
	int count=1;
	char filename [ FILENAME_MAX ];
	system("cls");
	printf("\tALL CONTACT: \n\n");
	struct contact *ptr = head;

	while(ptr != NULL) {
        sprintf(filename, "image%d.bmp", count);
		printf(" First Name\t: %s\n Last Name\t: %s\n Phone Number\t: %s\n Image Filename\t: ",ptr->fname, ptr->lname, ptr->phone);
      	openPicture(filename, max);
      	printf("\n------------------------------------\n");
      	count++;
		ptr = ptr->next;
	}
	system("pause");
}

int addContact(int max){
	system("cls");
	printf("\tADD CONTACT  \n\n");

	//Inserting data
	char fname[20];
	char lname[20];
	char phone[20];
	struct contact *link = (struct contact*) malloc(sizeof(struct contact));
	printf("First Name\t: ");
	scanf("%s", &fname);
   	strcpy(link->fname, fname);
   	printf("Last Name\t: ");
	scanf("%s", &lname);
   	strcpy(link->lname, lname);
   	printf("Phone Number\t: ");
	scanf("%s", &phone);
   	strcpy(link->phone, phone);
   	printf("\n");
   	link->next = head;
   	head = link;
    printf("To add image to contact please copy .bmp image file with name image%d.bmp to project folder\n\n\tContact has been added!\n\n", max+1);
   	system("pause");
   	return max++;
}

void deleteFirst(){
	char search[20];
	int found=0;
	struct contact *ptr = head;
	struct contact *prev;
	struct contact *temp;

	printf("\nEnter First name: ");
	scanf("%s", &search);
	/* delete first node */
	if(strcmp(head->fname, search)==0){
		temp = head;
		head = head->next; /* de-thread the node */
		free( temp ); /* free the de-threaded node */
		found=1;
	} /* end if */
	else {
		prev = ptr;
		ptr = ptr->next;

		/* loop to find the correct location in the list */
		while ( ptr != NULL){
			if(strcmp(ptr->fname, search)==0){
				found=1;
				break;
			}
			else{
				prev = ptr; /* walk to ... */
				ptr = ptr->next; /* ... next node */
			}
		} /* end while */
		/* delete node at currentPtr */
		if ( ptr != NULL ) {
			temp = ptr;
			prev->next = ptr->next;
			free( temp );
		} /* end if */
	} /* end else */

	if (found==1){
		printf("\n\tContact has been deleted !\n\n");
	}
	else{
		printf("\n\tContact not found.\n\n");
	}
	system("pause");
}

void deleteLast(){
	char search[20];
	int found=0;
	struct contact *ptr = head;
	struct contact *prev;
	struct contact *temp;

	printf("\nEnter Last name: ");
	scanf("%s", &search);
	/* delete first node */
	if(strcmp(head->lname, search)==0){
		temp = head;
		head = head->next; /* de-thread the node */
		free( temp ); /* free the de-threaded node */
		found=1;
	} /* end if */
	else {
		prev = ptr;
		ptr = ptr->next;

		/* loop to find the correct location in the list */
		while ( ptr != NULL){
			if(strcmp(ptr->lname, search)==0){
				found=1;
				break;
			}
			else{
				prev = ptr; /* walk to ... */
				ptr = ptr->next; /* ... next node */
			}
		} /* end while */
		/* delete node at currentPtr */
		if ( ptr != NULL ) {
			temp = ptr;
			prev->next = ptr->next;
			free( temp );
		} /* end if */
	} /* end else */

	if (found==1){
		printf("\n\tContact has been deleted !\n\n");
	}
	else{
		printf("\n\tContact not found.\n\n");
	}
	system("pause");
}

void deleteNum(){
	char search[20];
	int found=0;
	struct contact *ptr = head;
	struct contact *prev;
	struct contact *temp;

	printf("\nEnter Phone number: ");
	scanf("%s", &search);
	/* delete first node */
	if(strcmp(head->phone, search)==0){
		temp = head;
		head = head->next; /* de-thread the node */
		free( temp ); /* free the de-threaded node */
		found=1;
	} /* end if */
	else {
		prev = ptr;
		ptr = ptr->next;

		/* loop to find the correct location in the list */
		while ( ptr != NULL){
			if(strcmp(ptr->phone, search)==0){
				found=1;
				break;
			}
			else{
				prev = ptr; /* walk to ... */
				ptr = ptr->next; /* ... next node */
			}
		} /* end while */
		/* delete node at currentPtr */
		if ( ptr != NULL ) {
			temp = ptr;
			prev->next = ptr->next;
			free( temp );
		} /* end if */
	} /* end else */

	if (found==1){
		printf("\n\tContact has been deleted !\n\n");
	}
	else{
		printf("\n\tContact not found.\n\n");
	}
	system("pause");
}

void searchFirst(){
	char search[20];
	int found=0;
	struct contact *ptr = head;

	printf("\nEnter First name: ");
	scanf("%s", &search);
	/* loop to find the correct location in the list */
	while ( ptr != NULL){
		if(strcmp(ptr->fname, search)==0){
			printf("\n\tContact:\nFirst Name\t: %s\nLast Name\t: %s\nPhone Number\t: %s\n\n",ptr->fname, ptr->lname, ptr->phone);
			found=1;
			break;
		}
		else{
			ptr = ptr->next; /* ... next node */
		}
	} /* end while */

	if (found==0){
		printf("\n\tContact not found.\n\n.");
	}
	system("pause");
}

void searchLast(){
	char search[20];
	int found=0;
	struct contact *ptr = head;

	printf("\nEnter Last name: ");
	scanf("%s", &search);
	/* loop to find the correct location in the list */
	while ( ptr != NULL){
		if(strcmp(ptr->lname, search)==0){
			printf("\n\n\tContact:\nFirst Name\t: %s\n Last Name\t: %s\n Phone Number\t: %s\n\n",ptr->fname, ptr->lname, ptr->phone);
			found=1;
			break;
		}
		else{
			ptr = ptr->next; /* ... next node */
		}
	} /* end while */

	if (found==0){
		printf("Contact not found.\n\n.");
	}
	system("pause");
}

void searchNum(){
	char search[20];
	int found=0;
	struct contact *ptr = head;

	printf("\nEnter Phone number: ");
	scanf("%s", &search);
	/* loop to find the correct location in the list */
	while ( ptr != NULL){
		if(strcmp(ptr->phone, search)==0){
			printf("\n\n\tContact:\nFirst Name\t: %s\n Last Name\t: %s\n Phone Number\t: %s\n\n",ptr->fname, ptr->lname, ptr->phone);
			found=1;
			break;
		}
		else{
			ptr = ptr->next; /* ... next node */
		}
	} /* end while */

		if (found==0){
		printf("\n\tContact not found.\n\n.");
	}
	system("pause");
}

void sortFirst(){
	int count=0;

	struct contact *ptr = head;
	struct contact *ptrN = ptr->next;
	struct contact *temp = NULL;
	struct contact *prev = NULL;

	while ( ptrN != NULL){
	count++;
		if(strcmp(ptr->fname,ptrN->fname)>0){
			if(ptr==head){
				head=ptrN;
				ptr->next=ptrN->next;
				ptrN->next=ptr;
				ptr=ptrN;
			}
			else{
				temp=ptrN->next;
				prev->next=ptrN;
				ptrN->next=ptr;
				ptr->next=temp;
			}
			ptr=head;
			ptrN=head->next;
	    }
		else{
			prev = ptr;
			ptr = ptr->next;
			ptrN = ptrN->next; /* ... next node */
		}
	}
	printf("\n\tPhonebook has been sorted !\n\n");
	system("pause");
}

void sortLast(){
	int count=0;

	struct contact *ptr = head;
	struct contact *ptrN = ptr->next;
	struct contact *temp = NULL;
	struct contact *prev = NULL;

	while ( ptrN != NULL){
	count++;
		if(strcmp(ptr->lname,ptrN->lname)>0){
			if(ptr==head){
				head=ptrN;
				ptr->next=ptrN->next;
				ptrN->next=ptr;
				ptr=ptrN;
			}
			else{
				temp=ptrN->next;
				prev->next=ptrN;
				ptrN->next=ptr;
				ptr->next=temp;
			}
			ptr=head;
			ptrN=head->next;
	    }
		else{
			prev = ptr;
			ptr = ptr->next;
			ptrN = ptrN->next; /* ... next node */
		}
	}
	printf("\n\tPhonebook has been sorted !\n\n");
	system("pause");
}

void sortNum(){
	int count=0;

	struct contact *ptr = head;
	struct contact *ptrN = ptr->next;
	struct contact *temp = NULL;
	struct contact *prev = NULL;

	while ( ptrN != NULL){
	count++;
		if(strcmp(ptr->phone,ptrN->phone)>0){
			if(ptr==head){
				head=ptrN;
				ptr->next=ptrN->next;
				ptrN->next=ptr;
				ptr=ptrN;
			}
			else{
				temp=ptrN->next;
				prev->next=ptrN;
				ptrN->next=ptr;
				ptr->next=temp;
			}
			ptr=head;
			ptrN=head->next;
	    }
		else{
			prev = ptr;
			ptr = ptr->next;
			ptrN = ptrN->next; /* ... next node */
		}
	}
	printf("\n\tPhonebook has been sorted !\n\n");
	system("pause");
}
void saveFile(){
	//FILE OUTPUT
   	FILE *fptr;
   	fptr = fopen("phonebookTEST.txt","w+");

   	//Check if file opens
	if(fptr == NULL){
		printf("Error!");
		exit(1);
	}

	struct contact *ptr = head;

	while(ptr != NULL) {
		fprintf(fptr,"%20s\t%20s\t%20s\t%20d\n",ptr->fname, ptr->lname, ptr->phone, ptr->image);
		ptr = ptr->next;
	}
	printf("\n\tYour file has been saved !\n\n");
	system("pause");

	fclose(fptr);
}

int loadFile(){
    int max=0;
	//FILE INPUT
	FILE *fptr;
    fptr=fopen("phonebookTEST.txt","r+");
    //Check if file opens
	if(fptr == NULL){
		printf("Error!");
		exit(1);
	}

	char fname[20], lname[20], phone[20];
	int image;
    while(fscanf(fptr,"%s %s %s %d\n", fname, lname, phone, image)!=EOF)
    {
        struct contact *link = (struct contact*) malloc(sizeof(struct contact));
	   	strcpy(link->fname, fname);
	   	strcpy(link->lname, lname);
	   	strcpy(link->phone, phone);
	   	link->image=image;

        if(image>max){
            max=image;
        }

	   	link->next = head;
	   	head = link;
    }

	fclose(fptr);
    return max;
}

int isEmpty()
{
	return head == NULL;
} /* end function isEmpty */

void openPicture(char* filename, int max)
{
if(SDL_LoadBMP(filename)==0){
        printf("Image not found. (To add image to contact please copy .bmp image file with name image%d.bmp to project folder", max++);
        return 0;
}
else{
    printf("%s", filename);
int a = 1;
SDL_Event event;

SDL_Window* window = NULL;
SDL_Surface* background_surface = NULL;
SDL_Texture* background_texture = NULL;
SDL_Renderer* renderer = NULL;
SDL_Surface* button_surface = NULL;
SDL_Texture* button_texture = NULL;

SDL_Rect button_pos;
button_pos.w = 320;
button_pos.h = 65;
button_pos.x = 0;
button_pos.y = 0;

SDL_Init(SDL_INIT_VIDEO);
window = SDL_CreateWindow(
    "Profile Picture",
    SDL_WINDOWPOS_CENTERED,
    SDL_WINDOWPOS_CENTERED,
    580,
    400,
    SDL_WINDOW_SHOWN
);
renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
background_surface = SDL_LoadBMP(filename);
background_texture = SDL_CreateTextureFromSurface(renderer, background_surface);


while(a)
{
    SDL_PollEvent(&event);
    if(event.type == SDL_QUIT)
    {
        a = 0;
    }
    SDL_RenderClear(renderer);
    SDL_RenderCopy(renderer, background_texture, NULL, NULL);
    SDL_RenderCopy(renderer, button_texture, NULL, &button_pos);
    SDL_RenderPresent(renderer);
}

SDL_DestroyTexture(button_texture);
SDL_FreeSurface(button_surface);
SDL_DestroyRenderer(renderer);
SDL_DestroyTexture(background_texture);
SDL_FreeSurface(background_surface);
SDL_DestroyWindow(window);
SDL_Quit();
}
return 1;
}
